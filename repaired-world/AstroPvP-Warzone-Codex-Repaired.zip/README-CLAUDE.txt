AstroPvP Warzone Codex repaired test export

world/ is the complete repaired Minecraft 1.8.8 world, exported from world-edges-repaired, NOT the original world.
reports/all-changed-blocks.json contains 154,106 entries: [x,y,z,old_block_id,old_data,new_block_id,new_data].
All 154,106 final block values were checked against the repaired world before export.
SHA256SUMS.json records every world and report file for extraction verification.

Claude Code: extract to a NEW directory on Windows and test only on a separate, stopped, backed-up TacoSpigot 1.8.8 test-server copy. Do not overwrite the existing WarzoneTest world or production. No Windows Desktop or live server was accessed during this export. Lighting recalculation and real Minecraft visual tests remain required. See reports/BEFORE-AFTER.md for scope and limitations.
