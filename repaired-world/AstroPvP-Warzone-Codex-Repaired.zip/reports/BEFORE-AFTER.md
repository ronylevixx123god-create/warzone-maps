# Warzone perimeter repair — offline test copy

The left half of each PNG is the original exported world; the right half is the repaired copy. Images cover X/Z -208..207, north at top. These are block-data maps, not Minecraft client screenshots.

## Changes

Original arena X/Z -176..175 is untouched. The north strip X -176..175, Z -192..-177 was filled at surface Y69. West X -192..-177 and east X176..191 were extended over Z -192..191. South Z176..191 was filled where low terrain permitted, over X -176..175. Individual changed blocks, old/new numeric Minecraft IDs and data values are recorded in all-changed-blocks.json as [x,y,z,old_id,old_data,new_id,new_data].

Total: 154,106 changed blocks across 22,335 columns. New blocks are confined to Y63..71. Most added floor is Y69; short steps at Y70..71 meet the preexisting western terrain. Existing wood, grass and gray material at the adjacent arena edge determines the added surface. No new rocks, mountains, perimeter walls, lava or structures were added.

The south has 1,059 columns intentionally preserved for trees/obstacles or higher terrain. Exact locations are in preserved-columns.json. Some low areas under trees remain, and the outer terrain beyond this 16-block extension still needs inspection and a transition plan. This is a perimeter extension, not a completed restoration of the whole map.

## Preservation and validation

The original export, world-before backup and previous north-repaired world retain their file hashes. Readback checked every block of changed chunks and exact parsed equality of unchanged chunks. All changes match the coordinate logs. All new floor columns have solid support down to Y63. Adjacent repaired floor heights and their arena seam differ by at most one block. All original arena blocks, floating SafeZone, drop-down, purple beacon pavilion, entities and tile entities are unchanged.

World metadata HeightMap was updated and changed chunks marked LightPopulated=0 for server recalculation. Minecraft lighting, physics and rendering require a test server/client check; none was available. No real Minecraft screenshots were taken. No server was installed or modified.

## Files

world-edges-repaired/ is the complete edited world. Keep world-before/ as the immutable local backup. Do not deploy to production. Load a duplicate on a stopped, isolated TacoSpigot 1.8.8 test server; validate lighting and borders before considering any other use. The environment is Linux and the owner's Windows server is not mounted.

The reference screenshot package could not be transferred because of the tool size limit. No claims of matching the original images are made. Interior wood/grass redistribution and volcanic redesign are deferred until original images can be inspected.
